let numero = 1002;

document.getElementById("teste").innerHTML = numero;
//console.log(numero);
//window.alert("oi");
/** cria as variaveis para o um evento de botao */
const botao = document.getElementById("meubotao");
const mensagem = document.getElementById("mensagem");
/** Cria o evento de click do botao */
botao.addEventListener("click", function(){
    mensagem.textContent = "o botão foi clicado";
    botao.style.backgroundColor = "green";
});
/** Evento que muda o texto ao passar o mouse por cima */
botao.addEventListener("mouseover", function(){
    mensagem.textContent = " Voce passo o passo por cima ";
});
/** Evento de mouseout para resetar a mensagem quando sair do botao */
botao.addEventListener("mouseout", function(){
    mensagem.textContent = " ";
});
/** Seleciona os elementos pelo ID */
const botao2 = document.getElementById("botaoCapturar");
const inputNome = document.getElementById("nomeInput");
const mensagem2 = document.getElementById("mensagem");

/** Adiciona o evento de click do botao */
botao2.addEventListener("click", function(){
    const nome = inputNome.value;
    mensagem2.textContent = nome;
})
